# Dental Projetc > 2024-02-08 4:43pm
https://universe.roboflow.com/furkan-aydin-929es/dental-projetc

Provided by a Roboflow user
License: CC BY 4.0

